-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2021 at 07:44 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `discount`
--

CREATE TABLE `discount` (
  `product_id` int(15) NOT NULL,
  `product_type` varchar(20) DEFAULT NULL,
  `discount_type` varchar(30) DEFAULT NULL,
  `discount_description` tinytext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `discount`
--

INSERT INTO `discount` (`product_id`, `product_type`, `discount_type`, `discount_description`) VALUES
(192016, 'Soft drink', 'BUY 1-GET 1', 'If you buy one,get same one product as free.'),
(192017, 'Nut', 'Half-Price', 'This product you get 50% off.'),
(192020, 'Chanachur', 'Free Shipping', 'Orders occur within a certain period of time.'),
(192024, 'Sugar', 'Cash', 'Seller offer buying paying bill before due time.');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `product_id` int(15) NOT NULL,
  `product_type` varchar(20) DEFAULT NULL,
  `inventory_number` varchar(30) NOT NULL,
  `inventory_description` tinytext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`product_id`, `product_type`, `inventory_number`, `inventory_description`) VALUES
(192016, 'Soft drink', '1001', 'Item:Coca-cola; It\'s not sold.'),
(192018, 'Salt', '1002', 'Item:Sea salt; It\'s not sold.'),
(192020, 'Chanachur', '1005', 'Item: Bombay chanachur; It\'s not sold.'),
(192022, 'Chips', '1007', 'Item: Sun chips; It\'s not sold.'),
(192024, 'Sugar', '1009', 'Item: White sugar; It\'s not sold.');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `product_id` int(15) NOT NULL,
  `payment_customer_id` varchar(20) NOT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_amount` decimal(10,3) DEFAULT NULL,
  `payment_description` tinytext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`product_id`, `payment_customer_id`, `payment_date`, `payment_amount`, `payment_description`) VALUES
(192015, 'A-101', '2021-11-01', '150.000', 'Item:Meri-gold;Quantity:2 packet.'),
(192017, 'D-102', '2021-11-10', '400.000', 'Item:Almonds;Quantity: 1 kg.'),
(192019, 'F-105', '2021-11-19', '1200.000', 'Item:Miniket rice;Quantity:20 kg.'),
(192021, 'H-201', '2021-11-25', '600.000', 'Item:Fresh oil;Quantity:4 litre.'),
(192023, 'G-205', '2021-11-29', '75.000', 'Item:Dairy milk;Quantity: 5 pics.');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `product_id` int(15) NOT NULL,
  `sales_quantity` varchar(20) NOT NULL,
  `sales_amount` decimal(8,2) DEFAULT NULL,
  `sales_description` tinytext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`product_id`, `sales_quantity`, `sales_amount`, `sales_description`) VALUES
(192015, '2-packet', '100.00', 'Item: Meri-gold;'),
(192017, '1 kg', '500.00', 'Item: Almonds;'),
(192019, '25 kg', '1500.00', 'Item: Miniket rice'),
(192021, '5 litre', '750.00', 'Item: Fresh oil;'),
(192023, '10 pics', '150.00', 'Item: Dairy milk;');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `product_id` int(15) NOT NULL,
  `stock_item` varchar(20) DEFAULT NULL,
  `stock_number` int(10) NOT NULL,
  `product_type` varchar(30) DEFAULT NULL,
  `stock_description` tinytext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`product_id`, `stock_item`, `stock_number`, `product_type`, `stock_description`) VALUES
(192015, 'Meri-gold', 101, 'Biscuit', 'Flour-based baked food product.'),
(192016, 'Coca-cola', 102, 'Soft drink', 'World\'s favourite soft drink.'),
(192017, 'Almonds', 103, 'Nut', 'They are seeds,rather than a true nut.'),
(192018, 'Sea salt', 104, 'Salt', 'Salt produced evaporation of ocean water.'),
(192019, 'Miniket rice', 105, 'Rice', 'Kind of slender and glossy husked rice.'),
(192020, 'Bombay chanachur', 106, 'Chanachur', 'Indian sub-continental traditional snacks.'),
(192021, 'Fresh oil', 107, 'Liquied oil', 'Very popular and healthy brand of Bangladesh.'),
(192022, 'Sun chips', 108, 'Chips', 'Brand of fried grains.'),
(192023, 'Dairy milk', 109, 'Chocolate', 'British brand of milk chocolate.'),
(192024, 'White sugar', 110, 'Sugar', 'Crystallized sucrose extracted from either sugarcane.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`product_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `stock` (`product_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `sales` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
